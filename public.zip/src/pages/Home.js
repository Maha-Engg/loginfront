import React from "react";


const Home=()=>{
    return(
        <div className="Home">
            <h1> Welcome to My Home Site</h1>
        </div>
    );
};

export default Home;